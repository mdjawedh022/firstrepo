import './App.css';
import AllPages from './Components/AllPages';



function App() {
  return (
    <div className='App'>
      <AllPages />
    </div>
  );
}

export default App;
