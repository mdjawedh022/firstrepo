import React from "react";
import Products from "../components/Products/Products";
const Home = () => {
  return (
    <div style={{width: "70%", margin:"auto"}}>
      <Products />
    </div>
  );
};

export default Home;
