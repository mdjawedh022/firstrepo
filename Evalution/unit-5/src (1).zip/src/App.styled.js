import styled from "styled-components";

export const ParentWrapper = styled.div``;

export const ComponentWrapper = styled.div`
  display: flex;
  flex-direction: column;
  gap: 10px;
  justify-content: center;
  align-items: center;
  text-align: center;
`;

export const VariantWrapper = styled.div`
  display: flex;
  gap: 10px;
  justify-content: center;
  align-items: center;
  text-align: center;
`;

