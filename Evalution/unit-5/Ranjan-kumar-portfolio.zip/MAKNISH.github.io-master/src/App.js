import './App.css';
// import Navbar from "./Components/Navbar";
import MainPage from './Pages/MainPage';
// import ProjectsDummy from './Pages/ProjectsDummy';

function App() {
  return (
    <>
      <MainPage />
      {/* <Navbar /> */}
      {/* <Projects /> */}
    </>
  );
}

export default App;
