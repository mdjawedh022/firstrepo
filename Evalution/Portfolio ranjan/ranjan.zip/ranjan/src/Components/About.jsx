import React from "react";
import "./About.css";

const About = () => {
  return (
    <div name="about" className="Middle">
      <p>About Me</p>
      <p className="aboutsec">
        My Name is Ranjan kumar, I Live in Patna India, and I am a Full Stack
        Web Developer. I love exploring new technologies in the field of Web
        Development and always try to adapt to them. I believe in the concept of
        continuous learning by regularly upgrading my skills and enhancing my
        knowledge. I have learned MERN stack, data structures algorithms, and
        soft skills at Masai School. As a developer, my hunger for learning has
        drastically increased. And I want to centralize my skills and learning
        for the enhancement of an organization and more of it, to enhance my
        career.
      </p>
    </div>
  );
};

export default About;
