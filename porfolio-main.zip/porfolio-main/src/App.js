import "./App.css";
import Mainpages from "./Components/Pages/Mainpages";

function App() {
  return (
    <div className="App">
      <Mainpages />
    </div>
  );
}

export default App;
